import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Route, Switch } from 'react-router-dom';
import HomePage from './compontent/HomePage';
import Header from './compontent/Header';
import UserRead from './compontent/user/UserRead';
import UserList from './compontent/user/UserList';
import StorePage from './compontent/store/StorePage';

function App() {
    return (
        <div className="App">
            <Header />

            <Switch>
                <Route path="/" component={HomePage} exact />
                <Route path="/user/list" component={UserList} />
                <Route path="/user/read/:u_code" component={UserRead} />
                <Route path='/store' component={StorePage}/>
            </Switch>
        </div>
    );
}

export default App;
