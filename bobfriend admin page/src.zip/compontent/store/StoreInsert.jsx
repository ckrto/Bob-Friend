// 관리자용 웹 사용 X, 매장관리용 웹 사용 예정

import React from 'react'
import { Button, Card, Figure, Form, Row } from 'react-bootstrap'

const StoreInsert = () => {

    return (
        <Row className="justify-content-md-center">
            <Card
                className="my-3 py-4 px-5"
                style={{width: "80%"}}>
                <Card.Title>매장 등록</Card.Title>
                <Form style={{textAlign: "left"}}>
                    <Form.Label>Code</Form.Label>
                    <Form.Control
                        className="mb-3"
                        disabled={true}/>
                    <Form.Label>Category</Form.Label>
                    <Form.Control
                        className="mb-3"/>
                    <Form.Label>Name</Form.Label>
                    <Form.Control
                        className="mb-3"/>
                    <Form.Label>Location</Form.Label>
                    <Form.Control
                        className="mb-3"/>
                    <Form.Label>Tel</Form.Label>
                    <Form.Control
                        className="mb-3"/>
                    <Form.Label>Admin</Form.Label>
                    <Form.Control
                        className="mb-3"/>
                    <hr/>
                    <Figure.Image
                        width={200}
                        src="https://dummyimage.com/200"/>
                </Form>
            </Card>
            <div>
            <Button
                className="m-3"
                style={{width: "82%"}}>등록하기
            </Button>
            </div>
        </Row>
    )
}

export default StoreInsert