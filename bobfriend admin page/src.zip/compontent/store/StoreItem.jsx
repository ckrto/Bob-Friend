import axios from 'axios';
import React, { useEffect } from 'react'
import { Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const StoreItem = ({ store, callStores }) => {
    const {s_code, s_c_code, s_name, s_location, s_tel, s_admin} = store;

    const onClick = async() => {
        if(!window.confirm(`${s_code} 매장을 삭제하시겠습니까?`)) return;
        await axios.post(`/api/store/delete/${s_code}`);
        alert("삭제되었습니다.");
    }

    useEffect(() => {
        callStores();
    }, [])

    return (
        <tr>
            <td>{s_code}</td>
            {/* s_c_code view 생성 요망 */}
            <td>{s_c_code}</td>
            <td>
                <Link to={`/store/read/${s_code}`}>{s_name}</Link>
            </td>
            <td>{s_location}</td>
            <td>{s_tel}</td>
            <td>{s_admin}</td>
            <td>
                <Button
                       variant="outline-danger"
                       onClick={onClick}>Delete
                </Button>
            </td>
        </tr>
    )
}

export default StoreItem