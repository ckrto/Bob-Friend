import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Table } from 'react-bootstrap'
import StoreItem from './StoreItem';

const StoreList = () => {
    const [stores, setStores] = useState([]);

    const callStores = async() => {
        const result = await axios.get('/api/store/list');
        setStores(result.data);
    };

    useEffect(() => {
        callStores();
    });

    if(!stores) return <h2>Loading...</h2>

    return (
        <>
        <Table className="my-3">
            <thead>
                <tr>
                    <td>Code</td>
                    <td>Category</td>
                    <td>Name</td>
                    <td>Location</td>
                    <td>Tel</td>
                    <td>Admin</td>
                    <td>Delete</td>
                </tr>
            </thead>
            <tbody>
                {stores.map(store =>
                    <StoreItem
                        key={store.s_code}
                        store={store}
                        callStores={callStores}/>
                )}
            </tbody>
        </Table>
        </>
    )
}

export default StoreList