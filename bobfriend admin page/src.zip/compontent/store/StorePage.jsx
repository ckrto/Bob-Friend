import React from 'react'
import { Nav } from 'react-bootstrap'
import { Route } from 'react-router-dom';
import StoreInsert from './StoreInsert';
import StoreList from './StoreList';
import StoreRead from './StoreRead';

const StorePage = ({ history }) => {
    const onClick = (e) => {
        e.preventDefault();

        const href = e.target.getAttribute("href");
        history.push(href);
    }

    return (
        <div>
            <Nav fill variant="tabs" defaultActiveKey="/store/list">
                <Nav.Item>
                    <Nav.Link
                        href='/store/list'
                        onClick={onClick}>매장목록
                    </Nav.Link>
                </Nav.Item>
                <Nav.Item>
                    <Nav.Link
                        href='/store/insert'
                        onClick={onClick}>매장등록
                    </Nav.Link>
                </Nav.Item>
            </Nav>

            <Route path='/store/list' component={StoreList}/>
            <Route path='/store/insert' component={StoreInsert}/>
            <Route path='/store/read/:s_code' component={StoreRead}/>
        </div>
    )
}

export default StorePage