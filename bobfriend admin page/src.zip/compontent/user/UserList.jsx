import React from 'react'
import axios from 'axios';
import { useEffect, useState } from 'react'
import { Table } from 'react-bootstrap';
import UserItem from './UserItem';
import Pagination from 'react-js-pagination';
import '../Pagination.css'


const UserList = () => {
    const [users, setUsers] = useState([]);
    const [total,setTotal]=useState(0);
    const [form, setForm] = useState({
        column: 'u_id',
        query: '',
        page: 1,
        num: 5
    });

    const { column, query, page, num } = form;

    const onChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    }

    const onChangePage=(e)=>{
        setForm({
            ...form,
            page:e.target.value
        });
        callUsers();
    }

    const callUsers = async () => {
        const result = await axios.get(`/api/user/list?page=${page}&num=${num}&column=${column}&query=${query}`);
        setUsers(result.data.list);
        setTotal(result.data.total);
    }

    const onSubmit=(e)=>{
        e.preventDefault();
        callUsers();
    }

    useEffect(() => {
        callUsers();
    }, [column,num]);

    if (!users) return <h1>Loading...</h1>

    return (
        <div>
            <div className='search'>
                <form onSubmit={onSubmit}>
                    <select value={num} onChange={onChange} name="num">
                        <option value={5}>5명씩 보기</option>
                        <option value={10}>10명씩 보기</option>
                    </select>
                    <select value={column} onChange={onChange} name="column">
                        <option value="u_code">User Code</option>
                        <option value="u_name">User Name</option>
                        <option value="u_id">User ID</option>
                    </select>
                    <input placeholder='검색어' value={query} onChange={onChange} name="query" />
                    <button>검색</button>
                </form>
            </div>

            <div className='data'>
                <Table>
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Name</th>
                            <th>ID</th>
                            <th>Address</th>
                            <th>Del</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map(user =>
                            <UserItem key={user.u_code} user={user} callUsers={callUsers}/>
                        )}
                    </tbody>
                </Table>
            </div>
            <Pagination
                activePage={page}
                itemsCountPerPage={num}
                totalItemsCount={total}
                pageRangeDisplayed={20}
                prevPageText={"‹"}
                nextPageText={"›"}
                onChange={onChangePage} />
        </div>
    )
}

export default UserList